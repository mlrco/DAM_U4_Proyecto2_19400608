import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'modelo.dart';
import 'detalleAsignacion.dart';
import 'agregarAsignacion.dart';

class PantallaAsignaciones extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Asignaciones')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('asignaciones').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error al cargar las asignaciones'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          List<Asignacion> asignaciones = snapshot.data!.docs.map((doc) {
            Asignacion asignacion = Asignacion.fromMap(doc.data() as Map<String, dynamic>);
            asignacion.setId(doc.id);
            return asignacion;
          }).toList();

          if (asignaciones.isEmpty) {
            return Center(
              child: Text('No hay asignaciones registradas'),
            );
          }

          return ListView.builder(
            itemCount: asignaciones.length,
            itemBuilder: (context, index) {
              final asignacion = asignaciones[index];

              return ListTile(
                title: Text('Salón: ${asignacion.salon}'),
                subtitle: Text('Edificio: ${asignacion.edificio}\n'
                    'Horario: ${asignacion.horario}\n'
                    'Docente: ${asignacion.docente}\n'
                    'Materia: ${asignacion.materia}\n'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PantallaDetalleAsignacion(asignacion: asignacion),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PantallaAgregarAsignacion(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
