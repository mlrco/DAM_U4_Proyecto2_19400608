import 'package:flutter/material.dart';
import 'modelo.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PantallaAgregarAsignacion extends StatefulWidget {
  @override
  _PantallaAgregarAsignacionState createState() =>
      _PantallaAgregarAsignacionState();
}

class _PantallaAgregarAsignacionState extends State<PantallaAgregarAsignacion> {
  final _formKey = GlobalKey<FormState>();

  String _salon = '';
  String _edificio = '';
  String _horario = '';
  String _docente = '';
  String _materia = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Agregar asignación')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Salón'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'El campo es obligatorio';
                  }
                  return null;
                },
                onSaved: (value) {
                  _salon = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Edificio'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'El campo es obligatorio';
                  }
                  return null;
                },
                onSaved: (value) {
                  _edificio = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Horario'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'El campo es obligatorio';
                  }
                  return null;
                },
                onSaved: (value) {
                  _horario = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Docente'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'El campo es obligatorio';
                  }
                  return null;
                },
                onSaved: (value) {
                  _docente = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Materia'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'El campo es obligatorio';
                  }
                  return null;
                },
                onSaved: (value) {
                  _materia = value!;
                },
              ),
              SizedBox(height: 16),
              ElevatedButton(
                child: Text('Guardar'),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    _guardarAsignacion();
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _guardarAsignacion() async{
    final asignacion = Asignacion(
      salon: _salon,
      edificio: _edificio,
      horario: _horario,
      docente: _docente,
      materia: _materia,
    );

    DocumentReference docRef = await FirebaseFirestore.instance
        .collection('asignaciones')
        .add(asignacion.toMap());
    asignacion.setId(docRef.id); // Establecer el ID del documento en el modelo

    Navigator.of(context).pop();
  }
}
