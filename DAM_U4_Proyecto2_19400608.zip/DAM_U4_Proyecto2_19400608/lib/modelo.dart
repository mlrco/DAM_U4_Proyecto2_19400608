class Asignacion {
  String? id;
  String? salon;
  String? edificio;
  String? horario;
  String? docente;
  String? materia;

  Asignacion({
    this.id,
    this.salon,
    this.edificio,
    this.horario,
    this.docente,
    this.materia,
  });

  Map<String, dynamic> toMap() {
    return {
      'salon': salon,
      'edificio': edificio,
      'horario': horario,
      'docente': docente,
      'materia': materia,
    };
  }

  factory Asignacion.fromMap(Map<String, dynamic>? map) {
    if (map == null) return Asignacion();

    return Asignacion(
      id: map['id'],
      salon: map['salon'],
      edificio: map['edificio'],
      horario: map['horario'],
      docente: map['docente'],
      materia: map['materia'],
    );
  }

  void setId(String id) {
    this.id = id;
  }
}

class Asistencia {
  DateTime? fechaHora;
  String? revisor;

  Asistencia({
    this.fechaHora,
    this.revisor,
  });

  Map<String, dynamic> toMap() {
    return {
      'FechaHora': fechaHora,
      'revisor': revisor,
    };
  }

  factory Asistencia.fromMap(Map<String, dynamic> map) {
    return Asistencia(
      fechaHora: map['FechaHora'].toDate(),
      revisor: map['revisor'],
    );
  }
}
