import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'modelo.dart';

class PantallaListaAsistencia extends StatelessWidget {
  final Asignacion asignacion;

  PantallaListaAsistencia({required this.asignacion});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Asistencia'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('asignaciones')
            .doc(asignacion.id)
            .collection('asistencias')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error al cargar la asistencia'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          List<Asistencia> asistencias = snapshot.data!.docs.map((doc) {
            return Asistencia.fromMap(doc.data() as Map<String, dynamic>);
          }).toList();

          if (asistencias.isEmpty) {
            return Center(
              child: Text('No hay registros de asistencia'),
            );
          }

          return ListView.builder(
            itemCount: asistencias.length,
            itemBuilder: (context, index) {
              final asistencia = asistencias[index];

              return ListTile(
                title: Text('FechaHora: ${asistencia.fechaHora.toString()}'),
                subtitle: Text('Revisor: ${asistencia.revisor}'),
              );
            },
          );
        },
      ),
    );
  }
}
