import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'modelo.dart';
import 'registrarAsistencia.dart';
import 'editarAsignacion.dart';
import 'listaAsistencia.dart';


class PantallaDetalleAsignacion extends StatelessWidget {
  final Asignacion asignacion;

  PantallaDetalleAsignacion({required this.asignacion});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle de Asignación'),
      ),
      body: SingleChildScrollView(child:
      Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Salón: ${asignacion.salon}'),
            Text('Edificio: ${asignacion.edificio}'),
            Text('Horario: ${asignacion.horario}'),
            Text('Docente: ${asignacion.docente}'),
            Text('Materia: ${asignacion.materia}'),
            SizedBox(height: 16.0),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaAgregarAsistencia(
                      asignacion: asignacion,
                    ),
                  ),
                );
              },
              child: Text('Registrar Asistencia'),
            ),
            SizedBox(height: 16.0),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaListaAsistencia(asignacion: asignacion),
                  ),
                );
              },
              child: Text('Ver Asistencia'),
            ),
            SizedBox(height: 16.0),

            Row(children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PantallaEditarAsignacion(asignacion: asignacion),
                    ),
                  );
                },
                child: Text('Actualizar Asignación'),
              ),

              ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Eliminar Asignación'),
                      content: Text('¿Estás seguro de que deseas eliminar esta asignación?'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('Cancelar'),
                        ),
                        TextButton(
                          onPressed: () {
                            FirebaseFirestore.instance
                                .collection('asignaciones')
                                .doc(asignacion.id)
                                .delete()
                                .then((value) {
                              Navigator.pop(context);
                              Navigator.pop(context);
                            }).catchError((error) {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text('Error'),
                                  content: Text('Ocurrió un error al eliminar la asignación.'),
                                  actions: [
                                    TextButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      child: Text('OK'),
                                    ),
                                  ],
                                ),
                              );
                            });
                          },
                          child: Text('Eliminar'),
                        ),
                      ],
                    ),
                  );
                },
                child: Text('Eliminar Asignación'),
              ),

            ],)
          ],
        ),
      ),
    )
    );
  }
}
