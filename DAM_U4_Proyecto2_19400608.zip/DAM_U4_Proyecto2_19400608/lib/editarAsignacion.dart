import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'modelo.dart';

class PantallaEditarAsignacion extends StatefulWidget {
  final Asignacion asignacion;

  PantallaEditarAsignacion({required this.asignacion});

  @override
  _PantallaEditarAsignacionState createState() => _PantallaEditarAsignacionState();
}

class _PantallaEditarAsignacionState extends State<PantallaEditarAsignacion> {
  TextEditingController _salonController = TextEditingController();
  TextEditingController _edificioController = TextEditingController();
  TextEditingController _horarioController = TextEditingController();
  TextEditingController _docenteController = TextEditingController();
  TextEditingController _materiaController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _salonController.text = widget.asignacion.salon ?? '';
    _edificioController.text = widget.asignacion.edificio ?? '';
    _horarioController.text = widget.asignacion.horario ?? '';
    _docenteController.text = widget.asignacion.docente ?? '';
    _materiaController.text = widget.asignacion.materia ?? '';
  }

  @override
  void dispose() {
    _salonController.dispose();
    _edificioController.dispose();
    _horarioController.dispose();
    _docenteController.dispose();
    _materiaController.dispose();
    super.dispose();
  }

  void guardarCambios() {
    widget.asignacion.salon = _salonController.text;
    widget.asignacion.edificio = _edificioController.text;
    widget.asignacion.horario = _horarioController.text;
    widget.asignacion.docente = _docenteController.text;
    widget.asignacion.materia = _materiaController.text;

    FirebaseFirestore.instance
        .collection('asignaciones')
        .doc(widget.asignacion.id)
        .update(widget.asignacion.toMap())
        .then((value) {
      Navigator.pop(context);
    }).catchError((error) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('Ocurrió un error al guardar los cambios.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Asignación'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Salón:'),
            SizedBox(height: 8.0),
            TextField(
              controller: _salonController,
            ),
            SizedBox(height: 16.0),
            Text('Edificio:'),
            SizedBox(height: 8.0),
            TextField(
              controller: _edificioController,
            ),
            SizedBox(height: 16.0),
            Text('Horario:'),
            SizedBox(height: 8.0),
            TextField(
              controller: _horarioController,
            ),
            SizedBox(height: 16.0),
            Text('Docente:'),
            SizedBox(height: 8.0),
            TextField(
              controller: _docenteController,
            ),
            SizedBox(height: 16.0),
            Text('Materia:'),
            SizedBox(height: 8.0),
            TextField(
              controller: _materiaController,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: guardarCambios,
              child: Text('Guardar Cambios'),
            ),
          ],
        ),
      ),
    );
  }
}
