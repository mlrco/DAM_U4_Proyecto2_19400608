import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PantallaConsultaPorRevisor extends StatelessWidget {
  final String revisor;

  PantallaConsultaPorRevisor({required this.revisor});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consultar Asistencia por Revisor: ${revisor}'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('asignaciones').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Error al obtener los datos');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          final asignaciones = snapshot.data!.docs;

          return ListView.builder(
            itemCount: asignaciones.length,
            itemBuilder: (context, index) {
              final asignacion = asignaciones[index];

              return StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('asignaciones')
                    .doc(asignacion.id)
                    .collection('asistencias')
                    .where('revisor', isEqualTo: revisor)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('Error al obtener los datos');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  }

                  final asistencias = snapshot.data!.docs;

                  if (asistencias.isEmpty) {
                    return SizedBox();
                  }

                  return Column(
                    children: [
                      ListTile(
                        title: Text('Docente: ${asignacion['docente']}\nSalon: ${asignacion['salon']}'),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: asistencias.length,
                        itemBuilder: (context, index) {
                          final asistencia = asistencias[index];
                          final fechaHora = (asistencia['FechaHora'].toDate() as DateTime);

                          final formattedFechaHora = DateFormat('dd-MM-yyyy HH:mm:ss').format(fechaHora);

                          return ListTile(
                            subtitle: Text('Fecha/Hora: $formattedFechaHora'),
                          );
                        },
                      ),
                      Divider(),
                    ],
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
