import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'modelo.dart';
import 'package:intl/intl.dart';

class PantallaConsultaAsistenciaDocente extends StatelessWidget {
  final String docente;

  PantallaConsultaAsistenciaDocente({required this.docente});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consultar Asistencia por Rango de fechas'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('asignaciones')
            .where('docente', isEqualTo: docente)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Error al obtener los datos');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          final asignaciones = snapshot.data!.docs;

          return ListView.builder(
            itemCount: asignaciones.length,
            itemBuilder: (context, index) {
              final asignacion = asignaciones[index];

              return StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('asignaciones')
                    .doc(asignacion.id)
                    .collection('asistencias')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('Error al obtener los datos');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  }

                  final asistencias = snapshot.data!.docs;

                  if (asistencias.isEmpty) {
                    return SizedBox();
                  }

                  return Column(
                    children: [
                      ListTile(
                        title: Text('Docente: ${asignacion['docente']}\nSalon: ${asignacion['salon']}'),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: asistencias.length,
                        itemBuilder: (context, index) {
                          final asistencia = asistencias[index];
                          final fechaHora = (asistencia['FechaHora'].toDate() as DateTime);
                          final revisor = asistencia['revisor'];

                          final formattedFechaHora = DateFormat('dd-MM-yyyy HH:mm:ss').format(fechaHora);

                          return ListTile(
                            subtitle: Text('Fecha/Hora: $formattedFechaHora\nRevisor: $revisor'),
                          );
                        },
                      ),
                      Divider(),
                    ],
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
