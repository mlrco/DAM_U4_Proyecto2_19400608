import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'consultaAsistenciaDocente.dart';
import 'consultaRangoFechas.dart';
import 'consultaRangoFechasEdificio.dart';
import 'consultaRevisor.dart';

class PantallaConsultas extends StatefulWidget {
  @override
  _PantallaConsultasState createState() => _PantallaConsultasState();
}

class _PantallaConsultasState extends State<PantallaConsultas> {
  TextEditingController docenteController = TextEditingController();
  DateTimeRange? fechaRange;
  TextEditingController edificioController = TextEditingController();
  TextEditingController revisorController = TextEditingController();

  Future<void> selectDateRange() async {
    final pickedDateRange = await showDateRangePicker(
      context: context,
      initialDateRange: fechaRange,
      firstDate: DateTime(2022),
      lastDate: DateTime(2025),
    );

    if (pickedDateRange != null) {
      setState(() {
        fechaRange = pickedDateRange;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consultas de Asistencia'),
      ),
      body: SingleChildScrollView( child:
      Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Consultar Asistencia de un Docente'),
            SizedBox(height: 8.0),
            TextField(
              controller: docenteController,
              decoration: InputDecoration(
                hintText: 'Ingrese el nombre del docente',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaConsultaAsistenciaDocente(
                      docente: docenteController.text,
                    ),
                  ),
                );
              },
              child: Text('Consultar'),
            ),
            SizedBox(height: 32.0),
            Text('Consultar Asistencia por Rango de Fechas'),
            SizedBox(height: 8.0),
            GestureDetector(
              onTap: selectDateRange,
              child: AbsorbPointer(
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Rango de fechas',
                    hintText: fechaRange != null
                        ? '${DateFormat('yyyy-MM-dd').format(fechaRange!.start)} - ${DateFormat('yyyy-MM-dd').format(fechaRange!.end)}'
                        : 'Seleccione un rango de fechas',
                  ),
                ),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaConsultaPorRangoFechas(
                      fechaInicio: fechaRange?.start ?? DateTime.fromMillisecondsSinceEpoch(0),
                      fechaFin: fechaRange?.end ?? DateTime.now(),
                    ),
                  ),
                );
              },
              child: Text('Consultar'),
            ),
            SizedBox(height: 32.0),
            Text('Consultar Asistencia por Rango de Fechas y Edificio'),
            SizedBox(height: 8.0),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: selectDateRange,
                    child: AbsorbPointer(
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Rango de fechas',
                          hintText: fechaRange != null
                              ? '${DateFormat('yyyy-MM-dd').format(fechaRange!.start)} - ${DateFormat('yyyy-MM-dd').format(fechaRange!.end)}'
                              : 'Seleccione un rango de fechas',
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 8.0),
                Expanded(
                  child: TextField(
                    controller: edificioController,
                    decoration: InputDecoration(
                      hintText: 'Ingrese el nombre del edificio',
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaConsultaRangoFechasEdificio(
                      fechaInicio: fechaRange?.start ?? DateTime.fromMicrosecondsSinceEpoch(0),
                      fechaFin: fechaRange?.end ?? DateTime.now(),
                      edificio: edificioController.text,
                    ),
                  ),
                );
              },
              child: Text('Consultar'),
            ),
            SizedBox(height: 32.0),
            Text('Consultar Asistencia por Revisor'),
            SizedBox(height: 8.0),
            TextField(
              controller: revisorController,
              decoration: InputDecoration(
                hintText: 'Ingrese el nombre del revisor',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PantallaConsultaPorRevisor(
                      revisor: revisorController.text,
                    ),
                  ),
                );
              },
              child: Text('Consultar'),
            ),
          ],
        ),
      )
    )
    );
  }
}
