import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'modelo.dart';

class PantallaAgregarAsistencia extends StatefulWidget {
  final Asignacion asignacion;


  PantallaAgregarAsistencia({
    required this.asignacion,

  });

  @override
  _PantallaAgregarAsistenciaState createState() => _PantallaAgregarAsistenciaState();
}

class _PantallaAgregarAsistenciaState extends State<PantallaAgregarAsistencia> {
  DateTime? fechaHora;
  String? revisor;

  void guardarAsistencia() {
    if (fechaHora != null && revisor != null) {
      final asistencia = Asistencia(
        fechaHora: fechaHora!,
        revisor: revisor!,

      );

      FirebaseFirestore.instance
          .collection('asignaciones')
          .doc(widget.asignacion.id)
          .collection('asistencias')
          .add(asistencia.toMap())
          .then((value) {
        Navigator.pop(context);
      }).catchError((error) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Error'),
            content: Text('Ocurrió un error al guardar la asistencia.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agregar Asistencia'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('FechaHora:'),
            SizedBox(height: 8.0),
            InkWell(
              onTap: () {
                showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2021),
                  lastDate: DateTime(2025),
                ).then((selectedDate) {
                  if (selectedDate != null) {
                    showTimePicker(
                      context: context,
                      initialTime: TimeOfDay.now(),
                    ).then((selectedTime) {
                      if (selectedTime != null) {
                        setState(() {
                          fechaHora = DateTime(
                            selectedDate.year,
                            selectedDate.month,
                            selectedDate.day,
                            selectedTime.hour,
                            selectedTime.minute,
                          );
                        });
                      }
                    });
                  }
                });
              },
              child: Container(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(4.0),
                ),
                child: Text(
                  fechaHora != null ? fechaHora.toString() : 'Seleccione una FechaHora',
                ),
              ),
            ),
            SizedBox(height: 16.0),
            Text('Revisor:'),
            SizedBox(height: 8.0),
            TextField(
              onChanged: (value) {
                setState(() {
                  revisor = value;
                });
              },
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: guardarAsistencia,
              child: Text('Guardar Asistencia'),
            ),
          ],
        ),
      ),
    );
  }
}
