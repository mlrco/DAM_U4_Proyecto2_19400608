import 'package:flutter/material.dart';
import 'verAsignaciones.dart';
import 'consultas.dart';


class Principal extends StatefulWidget {
  @override
  _PrincipalState createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Asistencia'),
        backgroundColor: Colors.blueGrey,
      ),
      body: _buildScreen(),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.note),
            label: 'Asignaciones',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Consultas',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildScreen() {
    switch (_selectedIndex) {
      case 0:
        return PantallaAsignaciones();
      case 1:
        return PantallaConsultas();
      default:
        return Container();
    }
  }
}
